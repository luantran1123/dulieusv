package com.owasp.authenticationservice.util.enums;

public enum UserRole {

    SIMPLE_USER,
    AGENT,
    ADMIN

}
