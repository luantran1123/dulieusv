package com.owasp.authenticationservice.util.enums;

public enum UserStatus {

    PENDING,
    APPROVED,
    DENIED,

}
