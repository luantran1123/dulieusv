package com.owasp.authenticationservice.services.impl;

import com.owasp.authenticationservice.services.IAuthorityService;
import org.springframework.stereotype.Service;

@Service
public class AuthorityService implements IAuthorityService {
}
