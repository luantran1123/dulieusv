package com.owasp.authenticationservice.services;

public interface IAuthorityService {
}
