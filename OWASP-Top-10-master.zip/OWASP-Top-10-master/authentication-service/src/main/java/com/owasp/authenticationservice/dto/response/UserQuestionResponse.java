package com.owasp.authenticationservice.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserQuestionResponse {

    private String question;

}
