#!/bin/sh

java -jar eureka-1.0.0.jar