package com.owasp.adservice.util.enums;

public enum GearshiftType {

    MANUAL,
    AUTOMATIC,
    SEMIAUTOMATIC

}
