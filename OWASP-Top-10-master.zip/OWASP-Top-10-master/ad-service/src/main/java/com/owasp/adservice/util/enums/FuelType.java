package com.owasp.adservice.util.enums;

public enum FuelType {

    DIESEL,
    BENZINE,
    GAS

}
