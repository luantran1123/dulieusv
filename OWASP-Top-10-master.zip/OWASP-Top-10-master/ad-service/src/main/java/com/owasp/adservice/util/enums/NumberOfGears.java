package com.owasp.adservice.util.enums;

public enum NumberOfGears {

    FOUR,
    FIVE,
    SIX,
    SEVEN,
    EIGHT,
    NINE,
    TEN

}
