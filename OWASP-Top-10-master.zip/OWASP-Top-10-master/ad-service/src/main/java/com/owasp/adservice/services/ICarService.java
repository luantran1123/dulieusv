package com.owasp.adservice.services;

public interface ICarService {
}
