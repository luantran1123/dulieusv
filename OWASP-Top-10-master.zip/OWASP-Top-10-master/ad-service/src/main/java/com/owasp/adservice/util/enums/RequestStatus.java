package com.owasp.adservice.util.enums;

public enum RequestStatus {

    PENDING,
    PAID,
    CANCELED,
    RESERVED,

}
