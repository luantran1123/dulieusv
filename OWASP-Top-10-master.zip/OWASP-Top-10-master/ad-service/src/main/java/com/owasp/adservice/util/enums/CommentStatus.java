package com.owasp.adservice.util.enums;

public enum CommentStatus {

    PENDING,
    APPROVED,
    DENIED

}
