package com.owasp.adservice.services.impl;

import com.owasp.adservice.services.ICarService;
import org.springframework.stereotype.Service;

@Service
public class CarService implements ICarService {
}
