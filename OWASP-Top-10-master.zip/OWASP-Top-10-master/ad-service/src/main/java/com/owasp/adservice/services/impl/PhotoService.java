package com.owasp.adservice.services.impl;

import com.owasp.adservice.services.IPhotoService;
import org.springframework.stereotype.Service;

@Service
public class PhotoService implements IPhotoService {
}
