#!/bin/sh

java -jar zuul-1.0.0.jar