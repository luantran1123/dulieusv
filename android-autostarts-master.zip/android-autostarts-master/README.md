Android Autostarts Management Utility
-------------------------------------

[![BundleCop](https://api.bundlecop.com/badge/268318521568755716.svg?file=Android-Autostarts-Full.apk&label=APK%20Size)](https://app.bundlecop.com/project/268318521535987716)

Website

 * http://elsdoerfer.name/=android-autostarts

App

 * F-Droid<sup>1</sup> https://f-droid.org/en/packages/com.elsdoerfer.android.autostarts/
 * Google Play Store<sup>2</sup> https://play.google.com/store/apps/details?id=com.elsdoerfer.android.autostarts

Legend

 * <sup>1</sup>This F-Droid release is managed by a third party. The author of Autostarts is aware of this third party release, thankful for it, but cannot vouch for it. Related discussion at https://github.com/miracle2k/android-autostarts/issues/39
 * <sup>2</sup>This Google Play release is managed by the author.

Support & Contribute

 * https://github.com/miracle2k/android-autostarts/issues

Translations

 * http://www.transifex.net/projects/p/android-autostarts/

License

 * GPL 3 https://github.com/miracle2k/android-autostarts/blob/master/LICENSE
