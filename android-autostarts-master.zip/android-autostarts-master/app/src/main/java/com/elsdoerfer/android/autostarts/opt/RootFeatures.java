package com.elsdoerfer.android.autostarts.opt;

/**
 * Market-specific functionality.
 */
public class RootFeatures {

	public static final boolean Enabled = true;

}